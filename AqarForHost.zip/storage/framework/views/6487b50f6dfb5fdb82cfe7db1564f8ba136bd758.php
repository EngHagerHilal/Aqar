<?php
    $dir= str_replace('_', '-', app()->getLocale()) =='ar' ? 'rtl' : 'ltr';
?>
<?php $__env->startSection('content'); ?>
    <div id="container">
        <?php if(session('resent')): ?>
            <div class="alert alert-info py-5"> email activation sent success please check your inbox </div>
        <?php endif; ?>
        <h3 class="text-center py-5">Your Account need to Active </h3>
        <div class="text-center" >we allredy send email activation to your email address </div>
        <div class="text-center py-3">
            <a href="<?php echo e(route('verification.resend')); ?>"class="text-center btn btn-primary">resend email</a>
        </div>
    </div>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\aqar_project\aqar\Aqar\resources\views/firebase.blade.php ENDPATH**/ ?>