<?php $__env->startSection('PageTitle'); ?>Aqar - my profile <?php $__env->stopSection(); ?>
<?php
    $dir= str_replace('_', '-', app()->getLocale()) =='ar' ? 'rtl' : 'ltr';
    $textalign= str_replace('_', '-', app()->getLocale()) =='ar' ? 'text-right' : 'text-left';

?>
<?php $__env->startSection('notification'); ?>
    <?php if(auth()->user()): ?>
        <li class="nav-item text-white">
            <div class="dropdown show">

                <a href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i style="font-size: 1.4em" class="text-white far fa-bell"> <?php echo e($notification); ?></i>
                </a>
                <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                    <?php if(count($notificationContent)>0): ?>
                        <?php $__currentLoopData = $notificationContent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $not_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a class="dropdown-item" href="<?php echo e(route('postDetails',['post_id'=>$not_item->post_id])); ?>">
                                <strong><?php echo e($not_item->not_title); ?></strong>
                                <span style="font-size: .8em" class="text-right"><?php echo e($not_item->created_at); ?></span>
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <a class="dropdown-item" href="#!">
                            <strong><?php echo e(__('frontend.no_notification')); ?></strong>
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </li>

    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="main-news-container">
        <div class="container">
            <div dir="ltr" class="row">
                <div class="col-4 offset-4">
                    <div class="profile-container">
                        <div class="profile-img">
                            <img src="<?php echo e(asset('/')); ?>img/employer.webp" class="img-fluid d-block m-auto">
                        </div>
                        <br>
                        <br>
                        <br>
                        <div class="profile-text">
                            <h2 class="text-center"><?php echo e(Auth::user()->name); ?></h2>
                        </div>
                    </div>
                </div>
            </div>
            <br>
            <br>
            <ul dir="<?php echo e($dir); ?>" class="nav nav-pills row full-menu mb-3 m-auto ml-auto mr-auto" id="pills-tab" role="tablist">
                <li class="col text-center nav-item">
                    <a class="text-uppercase nav-link active" id="all-tab" data-toggle="pill" href="#all" role="tab" aria-controls="all" aria-selected="true"><?php echo e(__('frontend.all_posts')); ?>

                        [<?php echo e(count($ActiveRentPosts)+count($DisActiveRentPosts)+count($ActiveSellPosts)+count($DisActiveSellPosts)); ?>]</a>
                </li>
                <li class="col text-center nav-item">
                    <a class="text-uppercase nav-link" id="pills-rent-tab" data-toggle="pill" href="#pills-rent" role="tab" aria-controls="pills-rent" aria-selected="false"><?php echo e(__('frontend.rent_posts')); ?> [<?php echo e(count($ActiveRentPosts)+count($DisActiveRentPosts)); ?>]</a>
                </li>
                <li class="col text-center nav-item">
                    <a class="text-uppercase nav-link" id="pills-sell-tab" data-toggle="pill" href="#pills-sell" role="tab" aria-controls="pills-rent" aria-selected="false"><?php echo e(__('frontend.sel_posts')); ?> [<?php echo e(count($ActiveSellPosts)+count($DisActiveSellPosts)); ?>]</a>
                </li>
            </ul>
            <hr>
            <div class="tab-content full-menu-container text-center" id="pills-tabContent">
                <div class="tab-pane fade show active" id="all" role="tabpanel" aria-labelledby="all-tab"><h3 class="text-center"><?php echo e(__('frontend.all_posts')); ?></h3>
                    <div class="row border">
                        <?php $__currentLoopData = $ActiveRentPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $postItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div data-aos="fade-right"   data-aos-duration="500" class="col-sm-6 col-md-4 col-lg-3 mt-4">
                                <div class="card rounded-0">
                                    <img height="270" class="card-img-top" src="<?php echo e(asset($postItem->mainImage)); ?>">
                                    <div class="card-block">
                                        <h4 class="card-title text-center"><a href="<?php echo e(route('postDetails',['post_id'=>$postItem->id])); ?>"><?php echo e($postItem->post_name); ?></a></h4>
                                        <div class="card-text">
                                            <?php echo e($postItem->desc); ?>

                                        </div>
                                    </div>
                                    <div class="card-footer">
                                        <span class="float-right"><i class="far fa-calendar-check"></i> <?php echo e($postItem->created_at); ?></span>
                                        <span><i class=""></i><i class="far fa-comments"></i> 75 </span>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $DisActiveRentPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $postItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div data-aos="fade-right"   data-aos-duration="500" class="col-sm-6 col-md-4 col-lg-3 mt-4">
                                <div class="card rounded-0">
                                    <img height="270" class="card-img-top" src="<?php echo e(asset($postItem->mainImage)); ?>">
                                    <div class="card-block">
                                        <h4 class="card-title text-center"><a href="<?php echo e(route('postDetails',['post_id'=>$postItem->id])); ?>"><?php echo e($postItem->post_name); ?></a></h4>
                                        <div class="card-text">
                                            <?php echo e($postItem->desc); ?>

                                        </div>
                                    </div>
                                    <div class="card-footer">
                                        <span class="float-right"><i class="far fa-calendar-check"></i> <?php echo e($postItem->created_at); ?></span>
                                        <span><i class=""></i><i class="far fa-comments"></i> 75 </span>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $ActiveSellPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $postItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div data-aos="fade-right"   data-aos-duration="500" class="col-sm-6 col-md-4 col-lg-3 mt-4">
                                <div class="card rounded-0">
                                    <img height="270" class="card-img-top" src="<?php echo e(asset($postItem->mainImage)); ?>">
                                    <div class="card-block">
                                        <h4 class="card-title text-center"><a href="<?php echo e(route('postDetails',['post_id'=>$postItem->id])); ?>"><?php echo e($postItem->post_name); ?></a></h4>
                                        <div class="card-text">
                                            <?php echo e($postItem->desc); ?>

                                        </div>
                                    </div>
                                    <div class="card-footer">
                                        <span class="float-right"><i class="far fa-calendar-check"></i> <?php echo e($postItem->created_at); ?></span>
                                        <span><i class=""></i><i class="far fa-comments"></i> 75 </span>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $DisActiveSellPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $postItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div data-aos="fade-right"   data-aos-duration="500" class="col-sm-6 col-md-4 col-lg-3 mt-4">
                                <div class="card rounded-0">
                                    <img height="270" class="card-img-top" src="<?php echo e(asset($postItem->mainImage)); ?>">
                                    <div class="card-block">
                                        <h4 class="card-title text-center"><a href="<?php echo e(route('postDetails',['post_id'=>$postItem->id])); ?>"><?php echo e($postItem->post_name); ?></a></h4>
                                        <div class="card-text">
                                            <?php echo e($postItem->desc); ?>

                                        </div>
                                    </div>
                                    <div class="card-footer">
                                        <span class="float-right"><i class="far fa-calendar-check"></i> <?php echo e($postItem->created_at); ?></span>
                                        <span><i class=""></i><i class="far fa-comments"></i> 75 </span>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="tab-pane fade" id="pills-rent" role="tabpanel" aria-labelledby="pills-rent-tab"><h3 class="text-center"><?php echo e(__('frontend.rent_posts')); ?></h3>
                    <div class="row border">
                        <?php $__currentLoopData = $ActiveRentPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $postItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div data-aos="fade-right"   data-aos-duration="500" class="col-sm-6 col-md-4 col-lg-3 mt-4">
                                <div class="card rounded-0">
                                    <img height="270" class="card-img-top" src="<?php echo e(asset($postItem->mainImage)); ?>">
                                    <div class="card-block">
                                        <h4 class="card-title text-center"><a href="<?php echo e(route('postDetails',['post_id'=>$postItem->id])); ?>"><?php echo e($postItem->post_name); ?></a></h4>
                                        <div class="card-text">
                                            <?php echo e($postItem->desc); ?>

                                        </div>
                                    </div>
                                    <div class="card-footer">
                                        <span class="float-right"><i class="far fa-calendar-check"></i> <?php echo e($postItem->created_at); ?></span>
                                        <span><i class=""></i><i class="far fa-comments"></i> 75 </span>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $DisActiveRentPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $postItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div data-aos="fade-right"   data-aos-duration="500" class="col-sm-6 col-md-4 col-lg-3 mt-4">
                                <div class="card rounded-0">
                                    <img height="270" class="card-img-top" src="<?php echo e(asset($postItem->mainImage)); ?>">
                                    <div class="card-block">
                                        <h4 class="card-title text-center"><a href="<?php echo e(route('postDetails',['post_id'=>$postItem->id])); ?>"><?php echo e($postItem->post_name); ?></a></h4>
                                        <div class="card-text">
                                            <?php echo e($postItem->desc); ?>

                                        </div>
                                    </div>
                                    <div class="card-footer">
                                        <span class="float-right"><i class="far fa-calendar-check"></i> <?php echo e($postItem->created_at); ?></span>
                                        <span><i class=""></i><i class="far fa-comments"></i> 75 </span>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="tab-pane fade" id="pills-sell" role="tabpanel" aria-labelledby="pills-rent-tab"><h3 class="text-center"><?php echo e(__('frontend.sel_posts')); ?></h3>
                    <div class="row border">
                        <?php $__currentLoopData = $ActiveSellPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $postItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div data-aos="fade-right"   data-aos-duration="500" class="col-sm-6 col-md-4 col-lg-3 mt-4">
                                <div class="card rounded-0">
                                    <img height="270" class="card-img-top" src="<?php echo e(asset($postItem->mainImage)); ?>">
                                    <div class="card-block">
                                        <h4 class="card-title text-center"><a href="<?php echo e(route('postDetails',['post_id'=>$postItem->id])); ?>"><?php echo e($postItem->post_name); ?></a></h4>
                                        <div class="card-text">
                                            <?php echo e($postItem->desc); ?>

                                        </div>
                                    </div>
                                    <div class="card-footer">
                                        <span class="float-right"><i class="far fa-calendar-check"></i> <?php echo e($postItem->created_at); ?></span>
                                        <span><i class=""></i><i class="far fa-comments"></i> 75 </span>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $DisActiveSellPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $postItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div data-aos="fade-right"   data-aos-duration="500" class="col-sm-6 col-md-4 col-lg-3 mt-4">
                                <div class="card rounded-0">
                                    <img height="270" class="card-img-top" src="<?php echo e(asset($postItem->mainImage)); ?>">
                                    <div class="card-block">
                                        <h4 class="card-title text-center"><a href="<?php echo e(route('postDetails',['post_id'=>$postItem->id])); ?>"><?php echo e($postItem->post_name); ?></a></h4>
                                        <div class="card-text">
                                            <?php echo e($postItem->desc); ?>

                                        </div>
                                    </div>
                                    <div class="card-footer">
                                        <span class="float-right"><i class="far fa-calendar-check"></i> <?php echo e($postItem->created_at); ?></span>
                                        <span><i class=""></i><i class="far fa-comments"></i> 75 </span>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>






<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\aqar_project\aqar\Aqar\resources\views/profile.blade.php ENDPATH**/ ?>