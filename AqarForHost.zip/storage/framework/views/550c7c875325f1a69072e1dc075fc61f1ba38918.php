<?php $__env->startSection('PageTitle'); ?>Aqar -<?php echo e($page_title); ?> posts <?php $__env->stopSection(); ?>
<?php
    $dir= str_replace('_', '-', app()->getLocale()) =='ar' ? 'rtl' : 'ltr';
    $inputBorder= str_replace('_', '-', app()->getLocale()) =='ar' ? 'border-left-0' : 'border-right-0';
    $buttonBorder=  str_replace('_', '-', app()->getLocale()) =='ar' ? 'border-right-0' : 'border-left-0';
?>
<?php $__env->startSection('notification'); ?>
    <?php if(auth()->user()): ?>
        <li class="nav-item text-white">
            <div class="dropdown show">

                <a href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i style="font-size: 1.4em" class="text-white far fa-bell"> <?php echo e($notification); ?></i>
                </a>
                <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                    <?php if(count($notificationContent)>0): ?>
                        <?php $__currentLoopData = $notificationContent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $not_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a class="dropdown-item" href="<?php echo e(route('postDetails',['post_id'=>$not_item->post_id])); ?>">
                                <strong><?php echo e($not_item->not_title); ?></strong>
                                <span style="font-size: .8em" class="text-right"><?php echo e($not_item->created_at); ?></span>
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <a class="dropdown-item" href="#!">
                            <strong><?php echo e(__('frontend.no_notification')); ?></strong>
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </li>

    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="main-form-container ">
        <div class="container">
            <h2 class="text-center text-uppercase text-white"><strong><?php echo e(__('frontend.discover_your_city')); ?></strong></h2>
            <br>
            <br><div class="text-center row align-items-center">

                <div class="col-md-5 m-auto btn-group" role="group" aria-label="First group">
                    <br>
                    <button type="button" class="text-uppercase serch-filtering btn btn-secondary" filter-type="rent"><?php echo e(__('frontend.rent')); ?></button>
                    <button type="button" class="text-uppercase serch-filtering btn btn-secondary" filter-type="selling"><?php echo e(__('frontend.sel')); ?></button>
                    <button type="button" class="text-uppercase serch-filtering btn btn-secondary" filter-type=""><?php echo e(__('frontend.all_news')); ?></button>
                    <script>
                        $('button.serch-filtering').click(function () {
                            $(this).addClass('active btn-primary').siblings().removeClass('active');
                            $("#searchOption").val($(this).attr('filter-type'));
                        });
                    </script>
                </div>
            </div>
            <div class="text-center row align-items-center">

                <div class="col-md-5 m-auto">
                    <form method="post" action="<?php echo e(route('search')); ?>" class="form-row">
                        <?php echo csrf_field(); ?>
                        <div class="form-group col-10 p-0">
                            <input type="hidden" name="searchOption" value="" id="searchOption">
                            <input type="text" placeholder="<?php echo e(__('frontend.search')); ?>" name="filterType" class="form-control rounded-0 <?php echo e($inputBorder); ?> form-control-lg">
                        </div>
                        <div class="form-group col-2 p-0">
                            <button type="submit" class="form-control bg-primary rounded-0 <?php echo e($buttonBorder); ?> form-control-lg p-0">
                                <i class="fas fa-lg fa-search"></i>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

    </div>
    <div class="main-news-container">
        <div class="container-fluid">
            <h2 class="text-center text-capitalize"><?php echo e($seachText); ?></h2>

        </div>
        <div class="container">
            <div class="row border">
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $postItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div data-aos="fade-right"   data-aos-duration="500" class="col-sm-6 col-md-4 col-lg-3 mt-4">
                        <div class="card rounded-0">
                            <img height="270" class="card-img-top" src="<?php echo e(asset($postItem->mainImage)); ?>">
                            <div class="card-block">
                                <h4 class="card-title text-center"><a href="<?php echo e(route('postDetails',['post_id'=>$postItem->id])); ?>"><?php echo e($postItem->post_name); ?></a></h4>
                                <div class="card-text">
                                    <?php echo e($postItem->desc); ?>

                                </div>
                            </div>
                            <div class="card-footer">
                                <span class="float-right"><i class="far fa-calendar-check"></i> <?php echo e($postItem->created_at); ?></span>
                                <span><i class=""></i><i class="far fa-comments"></i> 75 </span>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>






<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\aqar_project\aqar\Aqar\resources\views/search.blade.php ENDPATH**/ ?>