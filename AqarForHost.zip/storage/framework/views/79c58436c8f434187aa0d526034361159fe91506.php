<?php
    $dir= str_replace('_', '-', app()->getLocale()) =='ar' ? 'rtl' : 'ltr';
    $textalign= str_replace('_', '-', app()->getLocale()) =='ar' ? 'text-right' : 'text-left';


?>
<?php $__env->startSection('PageTitle'); ?>Aqar - reset password <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class=" login-container">
        <div class="container">
            <div dir="ltr" class="row">
                <div class="offset-3 col-md-6 login-form-2">
                    <div  class="row">

                        <div class="col-8 offset-2">
                            <div class="profile-text">
                                <h2 class="text-center  text-white"><?php echo e($name); ?></h2>
                            </div>
                        </div>
                    </div>
                    <br>
                    <br>
                    <h3><?php echo e(__('frontend.resetPass')); ?> </h3>

                    <form autocomplete="off" dir="<?php echo e($dir); ?>" method="post" class="<?php echo e($textalign); ?>" action="<?php echo e(route('resetNewPass')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="form-group">
                            <label class="text-black" ><?php echo e(__('frontend.email')); ?></label>
                            <input required type="email" class="<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> form-control" placeholder="<?php echo e(__('frontend.email')); ?> " name="email" value="<?php echo e($email); ?>" />
                            <input required type="hidden" name="username" value="<?php echo e($name); ?>" />
                            <input required type="hidden" name="code" value="<?php echo e($code); ?>" />
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label class="text-black" ><?php echo e(__('frontend.new_password')); ?></label>

                            <input type="password" class="form-control" placeholder="<?php echo e(__('frontend.new_password')); ?>" name="newPassword" autocomplete="off" value="" />

                        </div>
                        <div class="form-group">
                            <label class="text-black" ><?php echo e(__('frontend.confirm_password')); ?></label>

                            <input type="password" class="form-control" name="repeatNewPass" placeholder="<?php echo e(__('frontend.confirm_password')); ?>" autocomplete="off" value="" />

                        </div>
                        <div class="form-group">
                            <input type="submit" class="btnSubmit w-50 p-lg-2 m-auto d-block" value="<?php echo e(__('frontend.update')); ?>" />
                        </div>
                        <div class="form-group">

                        </div>
                    </form>
                </div>
            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>






<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\aqar_project\aqar\Aqar\resources\views/auth/passwords/resetNewPassword.blade.php ENDPATH**/ ?>