/**
 * @return {!Object} The FirebaseUI config.
 */
function getUiConfig() {
    return {
        'callbacks': {
            // Called when the user has been successfully signed in.
            'signInSuccess': function(user, credential, redirectUrl) {
                var url = '/verfiy/phone';
                var form = $('<form action="' + url + '" method="post">' +
                    '<input type="hidden" name="_token" value="' + $('meta[name="csrf-token"]').attr('content') + '" />' +
                    '<input type="hidden" name="phone" value="' + user.phoneNumber + '" />' +
                    '</form>');
                $('body').append(form);
                form.submit();
                //alert($('meta[name="csrf-token"]').attr('content'));
                firebase.auth().signOut();
                // Do not redirect.
                return false;
            }
        },
        // Opens IDP Providers sign-in flow in a popup.
        'signInFlow': 'popup',
        'signInOptions': [
            // The Provider you need for your app. We need the Phone Auth
            firebase.auth.TwitterAuthProvider.PROVIDER_ID,
            {
                provider: firebase.auth.PhoneAuthProvider.PROVIDER_ID,
                recaptchaParameters: {
                    type: 'image', // another option is 'audio'
                    size: 'invisible', // other options are 'normal' or 'compact'
                    badge: 'bottomleft' // 'bottomright' or 'inline' applies to invisible.
                }
            }
        ],
        // Terms of service url.
        'tosUrl': 'https://www.google.com'
    };
}

// Initialize the FirebaseUI Widget using Firebase.
var ui = new firebaseui.auth.AuthUI(firebase.auth());

/**
 * Displays the UI for a signed in user.
 * @param {!firebase.User} user
 */
var handleSignedInUser = function(user) {
    document.getElementById('user-signed-in').style.display = 'block';
    document.getElementById('user-signed-out').style.display = 'none';
    document.getElementById('name').textContent = user.displayName;
    document.getElementById('email').textContent = user.email;
    document.getElementById('phone').textContent = user.phoneNumber;
    /*var url = '/verfiy/phone';
    var form = $('<form action="' + url + '" method="post">' +
        '<input type="hidden" name="_token" value="' + $('meta[name="csrf-token"]').attr('content') + '" />' +
        '<input type="hidden" name="phone" value="' + user.phoneNumber + '" />' +
        '</form>');
    $('body').append(form);
    form.submit();
    alert($('meta[name="csrf-token"]').attr('content'));
    //firebase.auth().signOut();
*/
    if (user.photoURL){
        document.getElementById('photo').src = user.photoURL;
        document.getElementById('photo').style.display = 'block';
    } else {
        document.getElementById('photo').style.display = 'none';
    }
};


/**
 * Displays the UI for a signed out user.
 */
var handleSignedOutUser = function() {
    document.getElementById('user-signed-in').style.display = 'none';
    document.getElementById('user-signed-out').style.display = 'block';
    ui.start('#firebaseui-container', getUiConfig());
};

// Listen to change in auth state so it displays the correct UI for when
// the user is signed in or not.
firebase.auth().onAuthStateChanged(function(user) {
    document.getElementById('loading').style.display = 'none';
    document.getElementById('loaded').style.display = 'block';
    user ? handleSignedInUser(user) : handleSignedOutUser();
});

/**
 * Deletes the user's account.
 */
var deleteAccount = function() {
    firebase.auth().currentUser.delete().catch(function(error) {
        if (error.code == 'auth/requires-recent-login') {
            // The user's credential is too old. She needs to sign in again.
            firebase.auth().signOut().then(function() {
                // The timeout allows the message to be displayed after the UI has
                // changed to the signed out state.
                setTimeout(function() {
                    alert('Please sign in again to delete your account.');
                }, 1);
            });
        }
    });
};

/**
 * Initializes the app.
 */
var initApp = function() {
    //redirect to active account page
    /*var url = '/verfiy/phone';
        var form = $('<form action="' + url + '" method="post">' +
            '<input type="hidden" name="_token" value="' + $('meta[name="csrf-token"]').attr('content') + '" />' +
            '<input type="hidden" name="phone" value="' + user.phoneNumber + '" />' +
            '</form>');
        $('body').append(form);
        firebase.auth().signOut();

        deleteAccount();

        form.submit();
    firebase.auth().signOut();
*/
    document.getElementById('sign-out').addEventListener('click', function() {

        firebase.auth().signOut();
    });
    document.getElementById('delete-account').addEventListener(
        'click', function() {
            deleteAccount();
        });
};

window.addEventListener('load', initApp);
