<?php $__env->startSection('PageTitle'); ?>Aqar -<?php echo e($page_title); ?> posts <?php $__env->stopSection(); ?>
<?php
    $dir= str_replace('_', '-', app()->getLocale()) =='ar' ? 'rtl' : 'ltr';
    $inputBorder= str_replace('_', '-', app()->getLocale()) =='ar' ? 'border-left-0' : 'border-right-0';
    $buttonBorder=  str_replace('_', '-', app()->getLocale()) =='ar' ? 'border-right-0' : 'border-left-0';
?>
<?php $__env->startSection('content'); ?>

    <div class="main-form-container ">
        <div class="container">
            <h2 class="text-center text-uppercase text-white"><strong><?php echo e(__('frontend.discover_your_city')); ?></strong></h2>
            <br>
            <br>
            <div class="text-center row align-items-center">

                <div class="col-md-5 m-auto btn-group" role="group" aria-label="First group">
                    <br>
                    <button type="button" class="text-uppercase serch-filtering btn btn-secondary" filter-type="rent"><?php echo e(__('frontend.rent')); ?></button>
                    <button type="button" class="text-uppercase serch-filtering btn btn-secondary" filter-type="selling"><?php echo e(__('frontend.sel')); ?></button>
                    <button type="button" class="text-uppercase serch-filtering btn btn-secondary" filter-type=""><?php echo e(__('frontend.all_news')); ?></button>
                    <script>
                        $('button.serch-filtering').click(function () {
                            $("#searchOption").val($(this).attr('filter-type'));
                        });
                    </script>
                </div>
            </div>
            <div class="text-center row align-items-center">
                <div class="col-md-5 m-auto">
                    <form method="post" action="<?php echo e(route('admin.search')); ?>" class="form-row">
                        <?php echo csrf_field(); ?>
                        <div class="form-group col-10 p-0">
                            <input type="hidden" name="searchOption" value="'all" id="searchOption">
                            <input type="text" placeholder="<?php echo e(__('frontend.search')); ?>" name="filterType" class="form-control rounded-0 <?php echo e($inputBorder); ?> form-control-lg">
                        </div>
                        <div class="form-group col-2 p-0">
                            <button type="submit" class="form-control bg-primary rounded-0 <?php echo e($buttonBorder); ?> form-control-lg p-0">
                                <i class="fas fa-lg fa-search"></i>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

    </div>
    <div class="main-news-container">
        <div class="container">
            <ul dir="<?php echo e($dir); ?>" class="nav nav-pills row full-menu mb-3 m-auto ml-auto mr-auto" id="pills-tab" role="tablist">
                <li class="col text-center nav-item">
                    <a class="text-uppercase nav-link active" id="pills-rent-tab" data-toggle="pill" href="#pills-rent" role="tab" aria-controls="pills-rent" aria-selected="true"><?php echo e(__('frontend.rent_posts')); ?> [<?php echo e(count($posts['rent']['active'])+count($posts['rent']['disActive'])); ?>]</a>
                </li>
                <li class="col text-center nav-item">
                    <a class="text-uppercase nav-link" id="pills-sell-tab" data-toggle="pill" href="#pills-sell" role="tab" aria-controls="pills-rent" aria-selected="false"><?php echo e(__('frontend.sel_posts')); ?> [<?php echo e(count($posts['sel']['active'])+count($posts['sel']['disActive'])); ?>]</a>
                </li>
            </ul>

        </div>
        <br>
        <div class="tab-content full-menu-container text-center" id="pills-tabContent">

            <div id="pills-rent" role="tabpanel" aria-labelledby="pills-rent-tab" class="show active tab-pane fade container border">
                <h2 class="text-center text-capitalize"><a href="#"><?php echo e(__('frontend.allPosts').' ' .__('frontend.rent')." ".__('frontend.active')); ?> [<?php echo e(count($posts['rent']['active'])); ?>]</a></h2>
                <div class="row ">
                    <?php $__currentLoopData = $posts['rent']['active']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $postItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div data-aos="fade-right"   data-aos-duration="500" class="col-sm-6 col-md-4 col-lg-3 mt-4">
                            <div class="card rounded-0">
                                <img height="270" class="card-img-top" src="<?php echo e(asset($postItem->mainImage)); ?>">
                                <div class="card-block">
                                    <h4 class="card-title text-center"><a href="<?php echo e(route('admin.postDetails',['post_id'=>$postItem->id])); ?>"><?php echo e($postItem->post_name); ?></a></h4>
                                    <div class="card-text">
                                        <?php echo e($postItem->desc); ?>

                                    </div>
                                </div>
                                <div class="card-footer">
                                    <span class="float-right"><i class="far fa-calendar-check"></i> <?php echo e($postItem->created_at); ?></span>
                                    <span><i class="fas fa-images"></i> <?php echo e($postItem->imgCount); ?> </span>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <br>
                <h2 class="text-center text-capitalize"><a href="#"><?php echo e(__('frontend.allPosts').' ' .__('frontend.rent')." ".__('frontend.disactive')); ?> [<?php echo e(count($posts['rent']['disActive'])); ?>]</a></h2>
                <div class="row ">
                    <?php $__currentLoopData = $posts['rent']['disActive']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $postItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div data-aos="fade-right"   data-aos-duration="500" class="col-sm-6 col-md-4 col-lg-3 mt-4">
                            <div class="card rounded-0">
                                <img height="270" class="card-img-top" src="<?php echo e(asset($postItem->mainImage)); ?>">
                                <div class="card-block">
                                    <h4 class="card-title text-center"><a href="<?php echo e(route('admin.postDetails',['post_id'=>$postItem->id])); ?>"><?php echo e($postItem->post_name); ?></a></h4>
                                    <div class="card-text">
                                        <?php echo e($postItem->desc); ?>

                                    </div>
                                </div>
                                <div class="card-footer">
                                    <span class="float-right"><i class="far fa-calendar-check"></i> <?php echo e($postItem->created_at); ?></span>
                                    <span><i class="fas fa-images"></i> <?php echo e($postItem->imgCount); ?> </span>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>


            </div>
            <div id="pills-sell" role="tabpanel" aria-labelledby="pills-sell-tab" class="tab-pane fade container border">
                <h2 class="text-center text-capitalize"><a href="#"><?php echo e(__('frontend.allPosts').' ' .__('frontend.sel')." ".__('frontend.active')); ?> [<?php echo e(count($posts['sel']['active'])); ?>]</a></h2>
                <div class="row ">
                    <?php $__currentLoopData = $posts['sel']['active']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $postItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div data-aos="fade-right"   data-aos-duration="500" class="col-sm-6 col-md-4 col-lg-3 mt-4">
                            <div class="card rounded-0">
                                <img height="270" class="card-img-top" src="<?php echo e(asset($postItem->mainImage)); ?>">
                                <div class="card-block">
                                    <h4 class="card-title text-center"><a href="<?php echo e(route('admin.postDetails',['post_id'=>$postItem->id])); ?>"><?php echo e($postItem->post_name); ?></a></h4>
                                    <div class="card-text">
                                        <?php echo e($postItem->desc); ?>

                                    </div>
                                </div>
                                <div class="card-footer">
                                    <span class="float-right"><i class="far fa-calendar-check"></i> <?php echo e($postItem->created_at); ?></span>
                                    <span><i class="fas fa-images"></i> <?php echo e($postItem->imgCount); ?> </span>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <br>
                <h2 class="text-center text-capitalize"><a href="#"><?php echo e(__('frontend.allPosts').' ' .__('frontend.sel')." ".__('frontend.disactive')); ?> [<?php echo e(count($posts['sel']['disActive'])); ?>]</a></h2>
                <div class="row ">
                    <?php $__currentLoopData = $posts['sel']['disActive']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $postItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div data-aos="fade-right"   data-aos-duration="500" class="col-sm-6 col-md-4 col-lg-3 mt-4">
                            <div class="card rounded-0">
                                <img height="270" class="card-img-top" src="<?php echo e(asset($postItem->mainImage)); ?>">
                                <div class="card-block">
                                    <h4 class="card-title text-center"><a href="<?php echo e(route('admin.postDetails',['post_id'=>$postItem->id])); ?>"><?php echo e($postItem->post_name); ?></a></h4>
                                    <div class="card-text">
                                        <?php echo e($postItem->desc); ?>

                                    </div>
                                </div>
                                <div class="card-footer">
                                    <span class="float-right"><i class="far fa-calendar-check"></i> <?php echo e($postItem->created_at); ?></span>
                                    <span><i class="fas fa-images"></i> <?php echo e($postItem->imgCount); ?> </span>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>






<?php echo $__env->make('admin.adminTemplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\aqar_project\aqar\resources\views/admin/adminPosts.blade.php ENDPATH**/ ?>