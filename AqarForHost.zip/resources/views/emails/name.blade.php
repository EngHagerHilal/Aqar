<!DOCTYPE html>
<html>
    <head>
        <title>Aqar reset password</title>
    </head>
<body>
    <div>{{$name}}</div>
</body>
</html>
