<?php

namespace App\Http\Controllers;

use App\posts;
use Illuminate\Http\Request;

class postDetailsController extends Controller
{

}
