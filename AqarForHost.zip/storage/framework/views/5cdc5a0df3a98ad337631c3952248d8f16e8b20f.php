<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\aqar_project\aqar\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>