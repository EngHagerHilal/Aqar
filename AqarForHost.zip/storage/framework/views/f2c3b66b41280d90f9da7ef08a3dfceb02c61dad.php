<?php $__env->startSection('PageTitle'); ?>Aqar -<?php echo e($page_title); ?> posts <?php $__env->stopSection(); ?>
<?php
    $dir= str_replace('_', '-', app()->getLocale()) =='ar' ? 'rtl' : 'ltr';
    $inputBorder= str_replace('_', '-', app()->getLocale()) =='ar' ? 'border-left-0' : 'border-right-0';
    $buttonBorder=  str_replace('_', '-', app()->getLocale()) =='ar' ? 'border-right-0' : 'border-left-0';
?>
<?php $__env->startSection('content'); ?>

    <div class="main-form-container ">
        <div class="container">
            <h2 class="text-center text-uppercase text-white"><strong><?php echo e(__('frontend.discover_your_city')); ?></strong></h2>
            <br>
            <br>
            <div class="text-center row align-items-center">

                <div class="col-md-5 m-auto btn-group" role="group" aria-label="First group">
                    <br>
                    <button type="button" class="text-uppercase serch-filtering btn btn-secondary" filter-type="rent"><?php echo e(__('frontend.rent')); ?></button>
                    <button type="button" class="text-uppercase serch-filtering btn btn-secondary" filter-type="selling"><?php echo e(__('frontend.sel')); ?></button>
                    <button type="button" class="text-uppercase serch-filtering btn btn-secondary" filter-type=""><?php echo e(__('frontend.all_news')); ?></button>
                    <script>
                        $('button.serch-filtering').click(function () {
                            $(this).addClass('active btn-primary').siblings().removeClass('active');
                            $("#searchOption").val($(this).attr('filter-type'));
                        });
                    </script>
                </div>
            </div>
            <div class="text-center row align-items-center">
                <div class="col-md-5 m-auto">
                    <form method="post" action="<?php echo e(route('search')); ?>" class="form-row">
                        <?php echo csrf_field(); ?>
                        <div class="form-group col-10 p-0">
                            <input type="hidden" name="searchOption" value="'all" id="searchOption">
                            <input type="text" placeholder="<?php echo e(__('frontend.search')); ?>" name="filterType" class="form-control rounded-0 <?php echo e($inputBorder); ?> form-control-lg">
                        </div>
                        <div class="form-group col-2 p-0">
                            <button type="submit" class="form-control bg-primary rounded-0 <?php echo e($buttonBorder); ?> form-control-lg p-0">
                                <i class="fas fa-lg fa-search"></i>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

    </div>
    <div class="main-news-container">
        <div class="container-fluid">
            <h2 class="text-center text-capitalize"><a href="#"><?php echo e(__('frontend.new_posts')); ?></a></h2>

            <div class="multi-slider" dir="ltr">
                <div class="row no-flow m-auto">
                    <div class=" slider-controler text-center slider-controler-right" id="next-slider"> &gt; </div>
                    <div class=" slider-container col-sm-10 offset-md-1">
                        <ul class="list-slider" style="transform: translate(368px);">
                            <?php
                                $fullOpacity='full-opacity';
                            ?>
                            <?php $__currentLoopData = $randomPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $postItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="slider-list-item multislider-item <?php echo e($fullOpacity); ?>">
                                <div class="card rounded-0">
                                    <img class="card-img-top" height="270" src="<?php echo e(asset($postItem->mainImage)); ?>">
                                    <div class="card-block">
                                        <h4 class="card-title text-center"><a href="<?php echo e(route('postDetails',['post_id'=>$postItem->id])); ?>"><?php echo e($postItem->post_name); ?></a></h4>
                                        <div class="text-right card-text">
                                            <?php echo e($postItem->desc); ?>

                                        </div>
                                    </div>
                                    <div class="card-footer">
                                        <span class="float-right"><i class="far fa-calendar-check"></i> <?php echo e($postItem->created_at); ?></span>
                                        <span><i class=""></i><i class="fas fa-images"></i> <?php echo e($postItem->imgCount); ?> </span>
                                    </div>
                                </div>
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </ul>
                    </div>
                    <div class=" slider-controler text-center slider-controler-left" id="pre-slider"> &lt; </div>

                </div>
            </div>
        </div>
        <div class="container">
            <h2 class="text-center text-capitalize"><a href="#"><?php echo e(__('frontend.'.$page_title)); ?></a></h2>
            <div class="row border">
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $postItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div data-aos="fade-right"   data-aos-duration="500" class="col-sm-6 col-md-4 col-lg-3 mt-4">
                        <div class="card rounded-0">
                            <img height="270" class="card-img-top" src="<?php echo e(asset($postItem->mainImage)); ?>">
                            <div class="card-block">
                                <h4 class="card-title text-center"><a href="<?php echo e(route('postDetails',['post_id'=>$postItem->id])); ?>"><?php echo e($postItem->post_name); ?></a></h4>
                                <div class="card-text">
                                    <?php echo e($postItem->desc); ?>

                                </div>
                            </div>
                            <div class="card-footer">
                                <span class="float-right"><i class="far fa-calendar-check"></i> <?php echo e($postItem->created_at); ?></span>
                                <span><i class=""></i><i class="fas fa-images"></i> <?php echo e($postItem->imgCount); ?> </span>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>






<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\aqar_project\aqar\resources\views/posts.blade.php ENDPATH**/ ?>